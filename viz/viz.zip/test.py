import graphviz
g = graphviz.Digraph('G', filename='cluster_edge.gv')
g.attr(compound='true')
with g.subgraph(name='cluster0') as c:
    c.node('a')
    c.node('b')
    c.node('e')

with g.subgraph(name='cluster1') as c:
    c.node('a')
    c.node('b')
    c.node('c')
print(g)